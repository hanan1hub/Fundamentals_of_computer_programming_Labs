#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

const int MAX_PRODUCTS = 5;
const int MAX_ORDER_LIMIT = 5;

// Product data
string products[MAX_PRODUCTS] = {"POLO SHIRT", "FORMAL PANTS", "SHOES(JOGGERS)", "FACE WASH", "GUCCI FLORA"};
float price[MAX_PRODUCTS] = {2500.0, 3500.0, 5000.0, 500.0, 10000.0};
int stock[MAX_PRODUCTS] = {20, 30, 10, 50, 5};

// Order data
int product_Indicies[MAX_ORDER_LIMIT];
int quantity[MAX_ORDER_LIMIT];
float order_Subtotal[MAX_ORDER_LIMIT];
int cart = 0;

// Function to display available items
void display_items()
{
	cout << "\nTHE AVAILABLE PRODUCTS ARE SHOWN BELOW:\n\n";
	for (int i = 0; i < MAX_PRODUCTS; i++)
	{
		cout << i + 1 << "- " << products[i]
			 << " | PRICE: Rs. " << price[i]
			 << " | STOCK: " << stock[i] << endl
			 << endl;
	}
}

// Function to add or update items in the order
bool add_items(int product_index, int qty)
{
	// Check if the product is already in the cart
	for (int i = 0; i < cart; i++)
	{
		if (product_Indicies[i] == product_index)
		{
			int new_quantity = quantity[i] + qty;

			if (new_quantity < 0)
			{
				cout << "PLEASE ENTER A POSITIVE QUANTITY.\n";
				return false;
			}
			if (new_quantity > stock[product_index] + quantity[i])
			{
				cout << "INSUFFICIENT STOCK for " << products[product_index] << ".\n";
				return false;
			}

			stock[product_index] -= (new_quantity - quantity[i]);
			quantity[i] = new_quantity;
			order_Subtotal[i] = price[product_index] * new_quantity;
			return true;
		}
	}

	// Add new product to the cart
	if (cart >= MAX_ORDER_LIMIT)
	{
		cout << "ORDER CAN'T HOLD MORE ITEMS.\n";
		return false;
	}
	if (qty <= 0 || qty > stock[product_index])
	{
		cout << "INVALID QUANTITY.\n";
		return false;
	}

	stock[product_index] -= qty;
	product_Indicies[cart] = product_index;
	quantity[cart] = qty;
	order_Subtotal[cart] = price[product_index] * qty;
	cart++;
	return true;
}

// Function to calculate gross total, discount, and tax
double calculateTotal(double &grossTotal, double &discount, double &tax)
{
	grossTotal = 0.0;
	double netTotal = 0.0;

	// Calculate gross total (sum of all subtotals)
	for (int i = 0; i < cart; i++)
	{
		grossTotal += order_Subtotal[i];
	}

	// Apply discount based on gross total
	if (grossTotal >= 10000.0)
	{
		discount = 0.10 * grossTotal; // 10% discount for orders over 10,000
	}
	else if (grossTotal >= 5000.0)
	{
		discount = 0.05 * grossTotal; // 5% discount for orders over 5,000
	}
	else
	{
		discount = 0.0;
	}

	// Calculate net total after discount
	netTotal = grossTotal - discount;

	// Calculate tax (8% of net total)
	tax = netTotal * 0.08;

	// Return final total (net total + tax)
	return netTotal + tax;
}

// Function to display order summary
void displayOrderSummary(double grossTotal, double discount, double tax, double Total)
{
	cout << fixed << setprecision(2);
	cout << "\nOrder Summary:\n";
	cout << "---------------------------------\n";

	for (int i = 0; i < cart; i++)
	{
		int productIndex = product_Indicies[i];
		cout << products[productIndex]
			 << " | Quantity: " << quantity[i]
			 << " | Subtotal: Rs. " << order_Subtotal[i] << endl;
	}

	cout << "---------------------------------\n";
	cout << "Gross Total (before discounts/tax): Rs. " << grossTotal << endl;
	cout << "Discount: Rs. " << discount << endl;
	cout << "Tax (8%): Rs. " << tax << endl;
	cout << "Final Total: Rs. " << Total << endl;
}

int main()
{
	int choice, qty;
	double grossTotal, discount, tax, finalTotal;
	cout << "\"WELCOME TO APNA STORE\"\n\n";
	cout << "-------------------------------------------------\n";
	cout << "| \t\tDEAL OF THE DAY\t\t\t\b |  \n";
	cout << "| ORDER ABOVE 4999 TO AVAil A DISCOUNT OF 5%  \t|\n";
	cout << "| ORDER ABOVE 9999 TO AVAil A DISCOUNT OF 10% \t|\n";
	cout << "-------------------------------------------------\n";
	// Order creation loop
	do
	{
		display_items();

		cout << "Enter product number to add/update order (0 to finish): ";
		cin >> choice;

		if (choice > 5)
		{
			cout << "ERROR:: INVALID CHOICE TRY NUMBER (0-5).\n\n";
			continue;
		}

		if (choice > 0 && choice <= MAX_PRODUCTS)
		{
			cout << "Enter quantity (negative to remove quantity): ";
			cin >> qty;

			if (!add_items(choice - 1, qty))
			{
				cout << "Could not update order.\n";
			}
		}

	} while (choice != 0);

	// Calculate total, discount, and tax, then display summary
	finalTotal = calculateTotal(grossTotal, discount, tax);
	displayOrderSummary(grossTotal, discount, tax, finalTotal);

	return 0;
}
